# Checkpoint 6 — Dynamic Programming | FIAP

## Identificação oficial — G01
- Grupo: **G01**
- Integrante informado: **RM563468** (nome não informado)
- Seed base: **8** (último dígito: 8)
- Seed final: **1008**
- ID da instância: **c4ecd5240e3b**
- Arquivos oficiais: `data/G01/`; gerador preenchido: `Gerador_Inputs_Checkpoint_6_G01.ipynb`.
- Os quatro CSV/JSON oficiais foram gerados executando todos os blocos do notebook disponibilizado, com **somente o Bloco 02 alterado**. O notebook original foi mantido intacto e a cópia está incluída para reprodutibilidade.

## Resultados da instância G01

**Questão 1:** Brute Force no subconjunto de 6 SKUs testou 117.649 combinações e encontrou caixa ótimo de **R$ 272.892,07**. O GA encontrou o mesmo valor, com **gap de 0,00%**. No catálogo completo, GA A e GA B encontraram **R$ 606.371,12** antes dos incentivos. Após o Greedy: caixa de **R$ 615.568,88**; meta de **R$ 416.991,12**; folga de **R$ 198.577,76**; cobertura da dívida **152,80%**; margem estimada **24,19%**; estoque remanescente estimado **1.581,05 unidades**; orçamento promocional gasto **R$ 23.770,45** de **R$ 108.759,24**. Valores são previsões baseadas nas hipóteses declaradas, não vendas realizadas.

**Questão 2:** Monte Carlo: **2.000 cenários** na estimativa e **5.000 cenários novos e independentes** na validação. As probabilidades simuladas de pagamento nas semanas 4, 8 e 12 foram **100%**, e a probabilidade conjunta observada também **100%** nos 5.000 cenários — não é garantia de pagamento futuro. Caixa final médio **R$ 233.079,65**, percentil 10 **R$ 228.970,17**, margem estimada **20,48%**, estoque final médio **723,66 unidades**. A DP otimiza contribuição esperada por SKU, **não** maximiza exatamente a probabilidade conjunta de solvência, uma limitação em relação à formulação ideal do enunciado.

**Otimização medida:** no benchmark do fitness, variante escalar **0,18672 s** / **0,193 MiB**, vetorizada **0,00124 s** / **1,210 MiB**, aceleração **150,98×** com maior memória de pico. São medições dessa execução, variáveis entre máquinas.

**Verificação:** os quatro testes existentes passaram e os hashes dos quatro arquivos oficiais foram conferidos. A documentação e testes são base para revisão e defesa pelo grupo; não representam garantia de todos os critérios de nota.

## Instalação e geração das entradas

1. Instale Python 3.10 ou superior e execute `pip install -r requirements.txt`.
2. Abra o notebook **Gerador_Inputs_Checkpoint_6(1).ipynb** original, sem alterar sua lógica.
3. Modifique **somente o Bloco 02**: `GRUPO` e `MATRICULAS` reais.
4. Execute todos os blocos. O notebook criará `dados_gerados/G01/` com 4 arquivos + `manifesto_dados.json`.
5. Copie o diretório `GXX` inteiro para `data/G01/`, preservando os hashes e nomes. Não edite nenhum CSV ou JSON.

```bash
python -m pytest -q
python questao_01/main.py --dados data/G01 --modo completo
python questao_02/main.py --dados data/G01 --cenarios 5000
```

## Integração da Questão 1

Nesta questão utilizamos 3 algoritmos. **Brute Force** enumera exatamente as combinações dos seis primeiros SKUs; **Algoritmo Genético** executa no mesmo subconjunto, permitindo medir gap percentual, e também no catálogo completo, buscando uma política de preços; **Greedy** usa os preços do GA como entrada e distribui incentivos com base no benefício marginal por real investido. Resultados, tempo, memória e gráfico de convergência saem em `questao_01/resultados/`.

**Modelagem:** demanda prevista = demanda_base × (preço/preço_atual)^(-elasticidade); unidades vendidas limitadas pelo estoque. Margem unitária = preço × (1-taxa_marketplace) − custo − logística. Caixa operacional = vendas × margem unitária. Descontos promocionais são tratados como custo do cupom, com aumento hipotético de demanda de 20% (hipótese adicional, não fornecida pelo gerador). A equipe deve validar essa hipótese.

## Integração da Questão 2

Nesta questão utilizamos 3 algoritmos. **Monte Carlo** estima demanda/caixa para opções de preço usando 2.000 cenários com flutuações de demanda, preço do concorrente e logística; a **Programação Dinâmica bottom-up** usa essas estimativas para decidir preço por semana e estoque restante; **Greedy** escolhe semanalmente quais SKUs recebem promoção. Em seguida, **Monte Carlo**, com outros 5.000 cenários independentes, estima os riscos dos compromissos das semanas 4, 8 e 12. Exporta trajetória por produto, cenários de validação, métricas e figuras.

**Limitação técnica relevante:** a DP faz otimização por SKU, com estoque discretizado e receita marginal esperada. Como caixa disponível e dívidas não fazem parte do estado da DP, esta solução **não maximiza rigorosamente a probabilidade conjunta de quitar todas as dívidas**, embora essa probabilidade seja estimada na validação. Uma extensão mais fiel usaria estado com caixa acumulado, risco/quantis e acoplamento entre SKUs, possivelmente com aproximação para conter a explosão de estados. Há outra aproximação: o Greedy estima custo de promoção com expectativa, enquanto a validação aplica seu custo fixo por semana.

## Resultados gerados

- `questao_01/resultados/resultado_q1.json`, `precos_q1.csv`, `convergencia_ga.png`
- `questao_02/resultados/resultado_q2.json`, `trajetoria_semanal.csv`, `cenarios_validacao.csv`, `distribuicao_caixa.png`, `trajetoria_precos.png`

## Defesa oral e cenário surpresa

Edite os JSONs **somente se forem cópias de cenário**; nunca altere arquivos oficiais. Para cenários-surpresa, adapte o programa para ler parâmetros de override externos, mantendo dados-base e hashes intactos. Explique primeiro a função de fitness e as margens, depois seleção/crossover/mutação, por fim a discretização da DP e a separação das sementes dos cenários.

## Nota sobre histórico

O ZIP não cria histórico Git fictício. Realize commits autênticos de acordo com as mudanças efetivamente feitas pelo grupo.

## Ética e transparência

Veja `IA_USO.md`; o grupo deve dominar e revisar o código antes da defesa.

## Otimização antes/depois

Compare o fitness escalar do GA com o fitness vetorizado, com população fixa e a mesma semente:

```bash
python questao_01/benchmark.py --dados data/G01
```

O arquivo `questao_01/resultados/benchmark_vetorizacao.json` fornece tempos, picos de memória e aceleração real na máquina usada.

**Tratamento de itens inviáveis na Q1:** se nenhum preço permitido respeitar o piso de margem, o SKU é excluído da venda (preço e unidades zero na saída); isso é uma decisão de modelagem, não uma alteração no arquivo oficial. Estoques e demandas podem ser fracionários por se tratar de previsão esperada.
