# Decisões e limitações

- A margem mínima foi interpretada como margem de contribuição / preço bruto.
- Os seis primeiros SKUs formam subconjunto reprodutível; 7^6 = 117.649 combinações para Q1.
- A estratégia GA usa torneio 3, crossover uniforme, mutação independente e elitismo.
- A Q2 assume demanda lognormal com média ~1, concorrente e logística lognormais independentes.
- A DP usa expectativa da simulação para cada preço, aproxima estoque em passos de 2 unidades e resolve separadamente por SKU.
- As quantias do Greedy são hipóteses explícitas para ligar benefícios promocionais à margem.
- Melhorias necessárias: incorporar objetivo de solvência diretamente na DP, modelar promoções com coerência exata e medir otimização antes/depois.
