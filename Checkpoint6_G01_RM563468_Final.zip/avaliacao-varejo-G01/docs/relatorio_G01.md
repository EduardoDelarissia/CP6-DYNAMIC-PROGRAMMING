# Relatório de execução — G01 — RM563468

Instância `c4ecd5240e3b`; seed_base=8; seed_final=1008. Arquivos em `data/G01/`. Dados oficiais gerados exclusivamente com a alteração de identificação do Bloco 02.

## Questão 1
- Subconjunto: 6 SKUs, 117.649 combinações; Brute Force R$ 272,892.07, GA R$ 272,892.07; gap 0.00%.
- GA A: R$ 606,371.12, tempo 0.0802 s. GA B: R$ 606,371.12, tempo 0.1300 s.
- Antes dos incentivos R$ 606,371.12; depois R$ 615,568.88; gasto R$ 23,770.45 / R$ 108,759.24.
- Meta R$ 416,991.12; folga R$ 198,577.76; cobertura da dívida 152.80%; margem estimada 24.19%.

## Questão 2
- Construção com 2000 cenários, validação independente com 5000 cenários.
- Probabilidade empírica de pagamento: semana 4: 100.0%; semana 8: 100.0%; semana 12: 100.0%; todas: 100.0%.
- Caixa final médio R$ 233,079.65; P10 R$ 228,970.17; estoque final médio 723.66 unidades.
- Limitação: otimização por SKU, não uma solução ótima exata da probabilidade conjunta de pagamento. Incentivos também usam aproximação de custo na seleção, distinta da contabilização na simulação.

## Escalabilidade da DP
- 6 SKUs: 0.4246 s, 0.0438 MiB, 454 estados.
- 12 SKUs: 0.9854 s, 0.0500 MiB, 983 estados.
- 24 SKUs: 1.9843 s, 0.0618 MiB, 2042 estados.

## Integridade SHA-256

- `q1_catalogo_G01.csv`: `8faac527006cc0e7c7ab724b3ef799ad2bf538609c807146b343710d48630406`
- `q1_config_G01.json`: `42b0e1cda986464d3a8696464bf49df56a5bdc091452420cbf35574f67415637`
- `q2_catalogo_G01.csv`: `5f7ffb2c7bad7b129e86840b56e704a44170d11a9a502e0fcd6a210f67438407`
- `q2_config_G01.json`: `b55ab6a44b07ee9ba4f44a80633c1f97b9a92b5c8da26594a2800c643c851c56`

**Transparência:** resultados simulados, sem garantia sobre realização futura. O uso de IA está registrado em `IA_USO.md`. É necessário revisar o código e preparar a defesa técnica.
