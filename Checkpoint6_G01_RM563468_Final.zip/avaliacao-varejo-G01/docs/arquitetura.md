# Arquitetura

```mermaid
flowchart TD
 A[Notebook oficial / Arquivos CSV e JSON] --> B[Verificação SHA-256]
 B --> C[Q1 Brute Force 6 SKUs]
 B --> D[Q1 GA 6 SKUs / GA catálogo]
 C --> E[Gap ótimo vs GA]
 D --> E
 D --> F[Q1 Greedy incentivos]
 B --> G[Q2 Monte Carlo estimativas]
 G --> H[Q2 DP preços semanais]
 H --> I[Q2 Greedy mídia]
 I --> J[Q2 Monte Carlo validação independente]
```
