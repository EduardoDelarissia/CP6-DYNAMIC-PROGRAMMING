# Como interpretar desempenho

Execute com dados oficiais, compare `resultado_q1.json` e `resultado_q2.json` e descreva em linguagem própria a diferença de tempo e memória. Valores reais dependem de CPU/RAM. Não há medições numéricas oficiais neste modelo.
