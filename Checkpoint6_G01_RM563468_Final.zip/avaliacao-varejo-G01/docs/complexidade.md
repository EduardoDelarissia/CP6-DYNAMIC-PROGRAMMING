# Big O e variáveis

Variáveis: `n` SKUs; `k` níveis de preço; `s` SKUs no subconjunto exato (6); `P` população; `G` gerações; `T` semanas (12); `M` cenários de Monte Carlo; `E` estados discretizados de estoque por SKU.

| Algoritmo | Tempo | Memória auxiliar | Dominante |
|--|--|--|--|
| Brute Force | O(s k^s) | O(sk+s) | Combinações no `product()` |
| GA | O(G P n + nk) | O(Pn + Gn + nk) (histórico implementado O(G)) | fitness e cruzamento por geração |
| Greedy Q1 | O(n log n) | O(n) | ordenação por razão benefício/custo |
| Monte Carlo construção | O(M T n k) | O(M T n + nk) | cenários e avaliação por nível |
| DP Q2 | O(T n E k) | O(n T E) para tabelas locais por SKU (pico O(T E + nT)) | 3 laços (semana, estoque, preço) |
| Greedy Q2 | O(T n log n) | O(n+Tn) | ordenar candidatos por semana |
| Monte Carlo validação | O(M T n) | O(M T n + M n) | choques e simulação de vendas |

Observação: a implementação de GA armazena `G+1` valores no histórico e não `Gn` indivíduos; memória é O(Pn + nk + G). A DP reinicia a tabela por SKU, então seu pico é O(TE + nT), não O(nTE). Os cenários Monte Carlo em memória crescem rapidamente com M, T e n. A otimização demonstrável do GA é o fitness vetorizado (NumPy) em vez de loops Python; para comprovar ganho **medido**, é preciso comparar explicitamente as duas implementações no mesmo computador. Os três tamanhos testados na Q2 são 6, 12 e 24 SKUs.
