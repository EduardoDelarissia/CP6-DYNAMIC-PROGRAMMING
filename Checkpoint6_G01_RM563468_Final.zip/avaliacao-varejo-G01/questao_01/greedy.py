"""Aloca incentivos discretos após escolher os preços."""
import numpy as np
from .brute_force import matriz_opcoes

def greedy(df,config,indices,percentual_desconto=0.05,elevacao_demanda=0.20):
    m=matriz_opcoes(df,config); orçamento=float(config['orcamento_promocional'])
    ofertas=[];total_inicial=0.
    for i,j in enumerate(indices):
        p=float(m['precos'][i,j]);q=float(m['unidades'][i,j]);unit=float(m['margens'][i,j])
        total_inicial+=q*unit
        # Cupom subsidiado: custo por unidade incremental e por unidade já vendida.
        qnovo=min(float(df.iloc[i]['estoque']),q*(1+elevacao_demanda))
        custo=percentual_desconto*p*qnovo
        ganho=qnovo*(unit-percentual_desconto*p)-q*unit
        if custo>0 and ganho>0 and (unit-percentual_desconto*p)/p>=config['margem_minima_percentual']:
            ofertas.append({'sku':str(df.iloc[i]['sku']),'custo':custo,'ganho':ganho,'razao':ganho/custo,'indice':i})
    ofertas.sort(key=lambda o:o['razao'],reverse=True)
    escolhidas=[];gasto=0.;ganho=0.
    for x in ofertas:
        if gasto+x['custo']<=orçamento:
            escolhidas.append(x);gasto+=x['custo'];ganho+=x['ganho']
    return {'caixa_antes':total_inicial,'caixa_depois':total_inicial+ganho,
            'gasto_incentivos':gasto,'orcamento':orçamento,'itens_incentivados':escolhidas}
