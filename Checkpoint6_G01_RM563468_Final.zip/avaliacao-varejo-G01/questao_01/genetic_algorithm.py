"""Algoritmo genético reprodutível com avaliação vetorizada."""
import numpy as np
from .brute_force import matriz_opcoes

def genetic_algorithm(df,config,seed,populacao=90,geracoes=140,mutacao=0.06,elitismo=3):
    rng=np.random.default_rng(seed)
    m=matriz_opcoes(df,config);n,k=m['caixa'].shape
    if any(not np.isfinite(m['caixa'][i]).any() for i in range(n)):
        raise ValueError('Produto sem preços viáveis')
    pop=rng.integers(k,size=(populacao,n))
    # Reparar gene inválido com a melhor opção permitida.
    def reparar(genes):
        for i in range(n):
            ruim=~m['validos'][i,genes[:,i]]
            genes[ruim,i]=int(np.argmax(m['caixa'][i]))
        return genes
    pop=reparar(pop)
    historico=[];melhor=-np.inf;melhor_ind=None
    for g in range(geracoes+1):
        fit=m['caixa'][np.arange(n)[None,:],pop].sum(axis=1)
        ordem=np.argsort(fit)[::-1]
        if fit[ordem[0]]>melhor:
            melhor=float(fit[ordem[0]]);melhor_ind=pop[ordem[0]].copy()
        historico.append(melhor)
        if g==geracoes:break
        elite=pop[ordem[:elitismo]].copy()
        # Torneios de 3 candidatos; cruzamento uniforme.
        amostras=rng.integers(populacao,size=(2*(populacao-elitismo),3))
        vencedores=amostras[np.arange(len(amostras)),np.argmax(fit[amostras],axis=1)]
        pais=pop[vencedores].reshape(2,populacao-elitismo,n)
        mascara=rng.random((populacao-elitismo,n))<0.5
        filhos=np.where(mascara,pais[0],pais[1])
        alterar=rng.random(filhos.shape)<mutacao
        filhos=np.where(alterar,rng.integers(k,size=filhos.shape),filhos)
        pop=np.concatenate([elite,reparar(filhos)],axis=0)
    return {'caixa':melhor,'indices':melhor_ind.tolist(),'historico':historico,
            'parametros':{'populacao':populacao,'geracoes':geracoes,'mutacao':mutacao,'elitismo':elitismo}}
