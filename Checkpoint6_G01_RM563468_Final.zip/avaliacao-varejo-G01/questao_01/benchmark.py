"""Compara implementação do fitness escalar com vetorizada."""
import sys,argparse,numpy as np
from pathlib import Path
if __package__ in (None,''):sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from utils import carregar,medir,salvar_json
from questao_01.brute_force import matriz_opcoes

def escalar(tab,pop):
    return np.array([sum(tab[i,int(g)] for i,g in enumerate(ind)) for ind in pop])

def vetorial(tab,pop):
    return tab[np.arange(tab.shape[0])[None,:],pop].sum(axis=1)

def executar(pasta):
    df,cfg,_=carregar(pasta,1);tab=matriz_opcoes(df,cfg)['caixa'];rng=np.random.default_rng(cfg['seed_final']);pop=rng.integers(tab.shape[1],size=(5000,len(df)))
    a,ma=medir(escalar,tab,pop);b,mb=medir(vetorial,tab,pop)
    assert np.allclose(a,b,equal_nan=True)
    resultado={'escalar':ma,'vetorial':mb,'ganho_tempo_x':ma['tempo_s']/max(mb['tempo_s'],1e-9)}
    destino=Path(__file__).parent/'resultados';destino.mkdir(exist_ok=True);salvar_json(destino/'benchmark_vetorizacao.json',resultado);print(resultado)
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--dados',required=True);a=ap.parse_args();executar(a.dados)
