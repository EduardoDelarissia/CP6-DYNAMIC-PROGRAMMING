import argparse,sys
from pathlib import Path
if __package__ in (None,''):
    sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from utils import carregar,medir,salvar_json
from questao_01.brute_force import brute_force,matriz_opcoes
from questao_01.genetic_algorithm import genetic_algorithm
from questao_01.greedy import greedy
import numpy as np
import matplotlib.pyplot as plt

def executar(pasta,saida=None,seed=None,modo='completo'):
    df,cfg,manifesto=carregar(pasta,1);seed=int(seed if seed is not None else cfg['seed_final'])
    saida=Path(saida or Path(__file__).parent/'resultados');saida.mkdir(parents=True,exist_ok=True)
    pequeno=df.iloc[:6].copy();exato,t1=medir(brute_force,pequeno,cfg)
    ag_pequeno,t2=medir(genetic_algorithm,pequeno,cfg,seed)
    gap=100*(exato['caixa']-ag_pequeno['caixa'])/max(abs(exato['caixa']),1e-9)
    ag,t3=medir(genetic_algorithm,df,cfg,seed)
    ag_alt,t4=medir(genetic_algorithm,df,cfg,seed+1,populacao=140,geracoes=210,mutacao=0.12)
    resultado=greedy(df,cfg,ag['indices']);m=matriz_opcoes(df,cfg)
    preco=np.array([m['precos'][i,j] for i,j in enumerate(ag['indices'])]);unid=np.array([m['unidades'][i,j] for i,j in enumerate(ag['indices'])]);margem=np.array([m['margens'][i,j] for i,j in enumerate(ag['indices'])])
    from pandas import DataFrame
    DataFrame({'sku':df.sku,'preco':preco,'vendas_previstas':unid,'estoque_final':df.estoque.to_numpy()-unid,'caixa_pre_greedy':unid*margem}).to_csv(saida/'precos_q1.csv',index=False)
    plt.figure();plt.plot(ag['historico'],label='GA A');plt.plot(ag_alt['historico'],label='GA B');plt.xlabel('Geração');plt.ylabel('Melhor caixa');plt.legend();plt.tight_layout();plt.savefig(saida/'convergencia_ga.png');plt.close()
    total=resultado['caixa_depois'];divida=float(cfg['divida_total_90d']);meta=float(cfg['meta_caixa_90d'])
    rel={'instancia':manifesto['id_instancia'],'benchmark':{'brute_force':exato,'ga_reduzido':{'caixa':ag_pequeno['caixa']},'gap_percentual':gap,'metricas_bf':t1,'metricas_ga':t2},'ga_a':{'caixa':ag['caixa'],'parametros':ag['parametros'],'medicao':t3},'ga_b':{'caixa':ag_alt['caixa'],'parametros':ag_alt['parametros'],'medicao':t4},'greedy':resultado,'resultado_final':{'caixa_operacional':total,'meta':meta,'folga_meta':total-meta,'divida':divida,'cobertura_divida_percentual':100*total/divida if divida else None,'margem_sobre_receita_percentual':100*(sum(unid*margem)+sum(x['ganho'] for x in resultado['itens_incentivados']))/max(sum(unid*preco),1),'estoque_remanescente':float(sum(df.estoque)-sum(unid))}}
    salvar_json(saida/'resultado_q1.json',rel)
    print('Q1:',rel['resultado_final']);return rel
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--dados',required=True);ap.add_argument('--saida');ap.add_argument('--seed',type=int);ap.add_argument('--modo',default='completo');a=ap.parse_args();executar(a.dados,a.saida,a.seed,a.modo)
