"""Busca exata de todas as combinações de preço do subconjunto."""
from itertools import product
import numpy as np

def matriz_opcoes(df,config):
    levels=np.asarray(config['niveis_preco_relativos'],dtype=float)
    p=df['preco_atual'].to_numpy(float)[:,None]*levels[None,:]
    d=df['demanda_base_90d'].to_numpy(float)[:,None]*levels[None,:]**(-df['elasticidade'].to_numpy(float)[:,None])
    vendidos=np.minimum(df['estoque'].to_numpy(float)[:,None],d)
    margem=p*(1-df['taxa_marketplace'].to_numpy(float)[:,None])-df['custo_unitario'].to_numpy(float)[:,None]-df['custo_logistico'].to_numpy(float)[:,None]
    # Margem mínima sobre o preço bruto.
    valida=(margem/p)>=float(config['margem_minima_percentual'])
    # Se o SKU não possui nenhum preço acima do piso, retirá-lo da oferta
    # (sem vender abaixo da margem mínima); não modificar o CSV oficial.
    sem_opcao=~valida.any(axis=1)
    valida[sem_opcao,0]=True
    vendidos[sem_opcao,0]=0.0
    p[sem_opcao,0]=0.0
    margem[sem_opcao,0]=0.0
    caixa=np.where(valida,vendidos*margem,-np.inf)
    return {'precos':p,'unidades':vendidos,'margens':margem,'caixa':caixa,'validos':valida}

def brute_force(df,config):
    m=matriz_opcoes(df,config);k=len(config['niveis_preco_relativos'])
    melhor=-np.inf;indices=None
    for candidato in product(range(k),repeat=len(df)):
        valor=sum(m['caixa'][i,j] for i,j in enumerate(candidato))
        if valor>melhor:melhor,indices=valor,candidato
    if indices is None:raise ValueError('Nenhuma combinação viável')
    return {'caixa':float(melhor),'indices':list(indices),'combinacoes':k**len(df)}
