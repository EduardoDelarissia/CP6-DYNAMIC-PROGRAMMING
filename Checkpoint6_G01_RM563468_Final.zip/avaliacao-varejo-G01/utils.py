"""Carregamento íntegro e medição de desempenho."""
import hashlib, json, time, tracemalloc
from pathlib import Path
import pandas as pd

def carregar(pasta, questao):
    pasta=Path(pasta)
    manifesto=json.loads((pasta/'manifesto_dados.json').read_text(encoding='utf8'))
    for nome, esperado in manifesto['arquivos'].items():
        caminho=pasta/nome
        if not caminho.exists() or hashlib.sha256(caminho.read_bytes()).hexdigest()!=esperado:
            raise ValueError(f'Arquivo ausente ou alterado: {nome}')
    grupo=manifesto['grupo']
    csv=pasta/f'q{questao}_catalogo_{grupo}.csv'
    cfg=pasta/f'q{questao}_config_{grupo}.json'
    return pd.read_csv(csv),json.loads(cfg.read_text(encoding='utf8')),manifesto

def medir(func,*args,**kwargs):
    tracemalloc.start();inicio=time.perf_counter()
    try: resultado=func(*args,**kwargs)
    finally:
        segundos=time.perf_counter()-inicio
        _,pico=tracemalloc.get_traced_memory();tracemalloc.stop()
    return resultado,{'tempo_s':segundos,'pico_memoria_mib':pico/1048576}

def salvar_json(caminho,obj):
    Path(caminho).write_text(json.dumps(obj,indent=2,ensure_ascii=False,default=lambda v:float(v)),encoding='utf8')
