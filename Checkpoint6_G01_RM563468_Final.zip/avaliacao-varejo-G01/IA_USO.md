# Registro de uso de IA generativa

Foi utilizada assistência de IA para gerar um **rascunho inicial** do código, testes, estrutura do projeto e documentação. A equipe deve revisar, testar, corrigir, adaptar e compreender cada parte, registrando as contribuições próprias e as ferramentas realmente utilizadas.

**Importante:** este registro não deve ser apagado nem apresentado como desenvolvimento exclusivamente humano. O notebook oficial de geração dos dados não foi modificado.
