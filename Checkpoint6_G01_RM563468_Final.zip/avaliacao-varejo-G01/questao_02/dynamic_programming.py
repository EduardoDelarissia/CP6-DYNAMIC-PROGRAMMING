"""DP bottom-up por SKU, estado (semana, estoque discretizado)."""
import numpy as np

def otimizar_produto(stock,quant,caixa,precos,base_preco,t=12,passo=1,risco=None):
    """DP com demanda média e unidades discretizadas; penaliza caixa negativo."""
    stock=int(stock);grade=np.arange(0,stock+1,passo)
    if grade[-1]!=stock:grade=np.append(grade,stock)
    g=len(grade);k=len(quant)
    v=np.zeros((t+1,g));politica=np.zeros((t,g),dtype=int)
    # Interpolação no estoque sucessor conserva estado reduzido sem sobre-vender.
    for semana in range(t-1,-1,-1):
        for i,s in enumerate(grade):
            melhor=-np.inf;melhor_j=0
            for j in range(k):
                venda=min(s,quant[j]);saldo=s-venda
                ganho=(caixa[j]/max(quant[j],1e-9))*venda
                futuro=np.interp(saldo,grade,v[semana+1])
                valor=ganho+futuro
                if valor>melhor:melhor,melhor_j=valor,j
            v[semana,i]=melhor;politica[semana,i]=melhor_j
    caminho=[];s=float(stock);trajetoria=[]
    for semana in range(t):
        idx=int(np.argmin(abs(grade-s)));j=int(politica[semana,idx]);caminho.append(j)
        s=max(0,s-min(s,quant[j]));trajetoria.append(s)
    return caminho,trajetoria,float(v[0,-1]),g

def planejar(df,cfg,estimativas,passo=2):
    semanas=int(cfg['numero_semanas']);politica=np.zeros((semanas,len(df)),dtype=int);estoques=[];estados=0
    for i,row in df.reset_index(drop=True).iterrows():
        caminho,estoque,_,g=otimizar_produto(row.estoque_inicial,estimativas['quantidade'][i],estimativas['caixa'][i],estimativas['precos'][i],row.preco_atual,t=semanas,passo=passo)
        politica[:,i]=caminho;estoques.append(estoque);estados+=g
    return politica.tolist(),np.asarray(estoques).T,estados
