"""Cenários independentes: demanda, concorrente e custo logístico."""
import numpy as np

def cenarios(df,cfg,n,seed):
    rng=np.random.default_rng(seed);t=int(cfg['numero_semanas']);m=len(df)
    sig=cfg['variabilidade']
    shape=(n,t,m)
    demanda=rng.lognormal(-sig['sigma_demanda']**2/2,sig['sigma_demanda'],size=shape)
    concorrente=rng.lognormal(-sig['sigma_preco_concorrente']**2/2,sig['sigma_preco_concorrente'],size=shape)
    logistica=rng.lognormal(-sig['sigma_custo_logistico']**2/2,sig['sigma_custo_logistico'],size=shape)
    return demanda,concorrente,logistica

def estimar_opcoes(df,cfg,n=2000,seed=0):
    dem,conc,log=cenarios(df,cfg,n,seed)
    levels=np.asarray(cfg['niveis_preco_relativos']);m=len(df);k=len(levels)
    p=df.preco_atual.to_numpy()[:,None]*levels
    concorr_base=df.preco_concorrente_base.to_numpy()
    elastic=df.elasticidade.to_numpy()
    demanda_base=df.demanda_base_semanal.to_numpy()
    custos=df.custo_unitario.to_numpy();taxas=df.taxa_marketplace.to_numpy();frete=df.custo_logistico_base.to_numpy()
    # For each price, Monte Carlo draws are shared, ensuring fair comparison.
    quant=np.empty((m,k));caixa=np.empty((m,k));p10=np.empty((m,k))
    for j in range(k):
        preco=p[:,j]
        fator_preco=(preco[None,None,:]/(concorr_base[None,None,:]*conc))**(-elastic[None,None,:])
        vendas=np.maximum(0,demanda_base[None,None,:]*dem*fator_preco)
        contrib=preco[None,None,:]*(1-taxas[None,None,:])-custos[None,None,:]-frete[None,None,:]*log
        resultado=vendas*contrib
        quant[:,j]=vendas.mean(axis=(0,1));caixa[:,j]=resultado.mean(axis=(0,1));p10[:,j]=np.percentile(resultado.mean(axis=1),10,axis=0)
    return {'quantidade':quant,'caixa':caixa,'p10':p10,'precos':p}

def validar(df,cfg,plano,incentivos,n=5000,seed=1):
    dem,conc,log=cenarios(df,cfg,n,seed);t=len(plano);m=len(df)
    estoque=np.broadcast_to(df.estoque_inicial.to_numpy(float),(n,m)).copy()
    caixa=np.full(n,float(cfg['caixa_inicial']));historico=[];pagou={};lucro=np.zeros(n);receita=np.zeros(n)
    debts={int(k.split('_')[-1]):float(v) for k,v in cfg['dividas'].items()}
    frac_promo=.12
    for w in range(t):
        indices=np.asarray(plano[w],dtype=int)
        levels=np.asarray(cfg['niveis_preco_relativos'])
        preco=df.preco_atual.to_numpy()*levels[indices]
        boost=np.array([frac_promo if i in incentivos[w] else 0 for i in range(m)])
        q=np.maximum(0,df.demanda_base_semanal.to_numpy()[None,:]*dem[:,w,:]*(preco[None,:]/(df.preco_concorrente_base.to_numpy()[None,:]*conc[:,w,:]))**(-df.elasticidade.to_numpy()[None,:])*(1+boost[None,:]))
        vendido=np.minimum(estoque,q);estoque-=vendido
        contribuicao=preco[None,:]*(1-df.taxa_marketplace.to_numpy()[None,:])-df.custo_unitario.to_numpy()[None,:]-df.custo_logistico_base.to_numpy()[None,:]*log[:,w,:]
        entrada=(vendido*contribuicao).sum(axis=1)
        # Recurso promocional contabilizado como custo fixo semanal por SKU.
        gasto=sum(incentivos[w].values());caixa+=entrada-gasto;lucro+=entrada-gasto;receita+=(vendido*preco).sum(axis=1)
        if w+1 in debts:
            ok=caixa>=debts[w+1];pagou[w+1]=ok.copy()
            caixa-=debts[w+1] # cenário negativo segue indicando insuficiência acumulada
        historico.append(caixa.copy())
    todos=np.logical_and.reduce(list(pagou.values()))
    return {'probabilidades_pagamento':{str(k):float(v.mean()) for k,v in pagou.items()},'probabilidade_todos':float(todos.mean()),'caixa_final_medio_apos_dividas':float(caixa.mean()),'caixa_final_p10':float(np.percentile(caixa,10)),'margem_sobre_receita_percentual':float(100*lucro.mean()/max(receita.mean(),1)),'estoque_final_medio':float(estoque.sum(axis=1).mean()),'fracasso_qualquer_parcela':float((~todos).mean()),'caixas_finais':caixa,'historico_caixa':np.asarray(historico),'estoque_final_por_sku':estoque.mean(axis=0)}
