import argparse,sys
from pathlib import Path
if __package__ in (None,''):
    sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from utils import carregar,medir,salvar_json
from questao_02.monte_carlo import estimar_opcoes,validar
from questao_02.dynamic_programming import planejar
from questao_02.greedy import alocar
import numpy as np,pandas as pd,matplotlib.pyplot as plt

def executar(pasta,saida=None,seed=None,cenarios=5000):
    df,cfg,manifesto=carregar(pasta,2);seed=int(seed if seed is not None else cfg['seed_final']);saida=Path(saida or Path(__file__).parent/'resultados');saida.mkdir(parents=True,exist_ok=True)
    if cenarios<5000:raise ValueError('Validação exige pelo menos 5000 cenários independentes')
    estima,met_mc=medir(estimar_opcoes,df,cfg,2000,seed+301)
    politica,met_dp=medir(planejar,df,cfg,estima)
    plano,estoque_prev,estados=politica
    recursos,met_g=medir(alocar,df,cfg,plano,estima,estoque_prev)
    resultado,met_val=medir(validar,df,cfg,plano,recursos,cenarios,seed+999)
    # Experimento de escalabilidade, preservando as mesmas estatísticas já calculadas.
    escalabilidade=[]
    for n in (6,12,len(df)):
        sub=df.iloc[:n];e={k:(v[:n] if hasattr(v,'shape') else v) for k,v in estima.items()}
        (_,_,state),med=medir(planejar,sub,cfg,e)
        escalabilidade.append({'skus':n,'estados_discretos':state,**med})
    precos=np.asarray(cfg['niveis_preco_relativos'])[np.asarray(plano)]*df.preco_atual.to_numpy()[None,:]
    linhas=[]
    for w in range(len(plano)):
        for i in range(len(df)):
            linhas.append({'semana':w+1,'sku':df.iloc[i].sku,'preco':precos[w,i],'estoque_previsto':estoque_prev[w,i],'promocao':int(i in recursos[w])})
    pd.DataFrame(linhas).to_csv(saida/'trajetoria_semanal.csv',index=False)
    pd.DataFrame({'caixa_final_apos_dividas':resultado['caixas_finais']}).to_csv(saida/'cenarios_validacao.csv',index=False)
    plt.figure();plt.hist(resultado['caixas_finais'],bins=45);plt.xlabel('Caixa final líquido após dívidas');plt.ylabel('Número de cenários');plt.tight_layout();plt.savefig(saida/'distribuicao_caixa.png');plt.close()
    plt.figure();plt.plot(range(1,13),precos[:,:min(3,len(df))]);plt.xlabel('Semana');plt.ylabel('Preços dos 3 primeiros SKUs');plt.tight_layout();plt.savefig(saida/'trajetoria_precos.png');plt.close()
    resumo={k:v for k,v in resultado.items() if not isinstance(v,np.ndarray)}
    resumo.update({'instancia':manifesto['id_instancia'],'construcao_mc':met_mc,'dp':met_dp,'greedy':met_g,'validacao_mc':met_val,'tamanhos_entrada':escalabilidade,'sementes':{'construcao':seed+301,'validacao':seed+999},'n_construcao':2000,'n_validacao':cenarios,'nota':'DP separável por SKU maximiza contribuição esperada, não garante probabilidade ótima conjunta de solvência.'})
    salvar_json(saida/'resultado_q2.json',resumo)
    print('Q2:',{k:v for k,v in resumo.items() if k in ['probabilidades_pagamento','probabilidade_todos','caixa_final_medio_apos_dividas','caixa_final_p10']});return resumo
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--dados',required=True);ap.add_argument('--saida');ap.add_argument('--seed',type=int);ap.add_argument('--cenarios',type=int,default=5000);a=ap.parse_args();executar(a.dados,a.saida,a.seed,a.cenarios)
