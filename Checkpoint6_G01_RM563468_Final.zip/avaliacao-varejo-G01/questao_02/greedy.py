"""Seleção semanal por benefício marginal líquido por real de promoção."""
import numpy as np

def alocar(df,cfg,plano,estimativas,estoque_previsto):
    budget=float(cfg['orcamento_promocional_semanal']);res=[]
    for w,indices in enumerate(plano):
        itens=[]
        for i,j in enumerate(indices):
            unidades=min(float(estoque_previsto[w-1,i]) if w else float(df.iloc[i].estoque_inicial),float(estimativas['quantidade'][i,j]))
            p=float(estimativas['precos'][i,j]);custo=0.03*p*unidades
            lucro_un=estimativas['caixa'][i,j]/max(estimativas['quantidade'][i,j],1e-9)
            extra=min(max(0,float(estoque_previsto[w-1,i])-unidades) if w else max(0,float(df.iloc[i].estoque_inicial)-unidades),unidades*0.12)
            beneficio=extra*lucro_un-custo
            if custo>0 and beneficio>0:itens.append((beneficio/custo,i,custo))
        gasto=0.;escolhidos={}
        for _,i,custo in sorted(itens,reverse=True):
            if gasto+custo<=budget:escolhidos[i]=custo;gasto+=custo
        res.append(escolhidos)
    return res
