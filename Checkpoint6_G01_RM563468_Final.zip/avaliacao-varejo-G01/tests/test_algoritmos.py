import numpy as np,pandas as pd
from questao_01.brute_force import brute_force
from questao_01.genetic_algorithm import genetic_algorithm
from questao_01.greedy import greedy
from questao_02.dynamic_programming import otimizar_produto
from questao_02.monte_carlo import cenarios

def fixture():
    df=pd.DataFrame([{'sku':f'X{i}','preco_atual':100.,'custo_unitario':40.,'taxa_marketplace':0.1,'custo_logistico':5.,'demanda_base_90d':20,'elasticidade':1.5,'estoque':30} for i in range(3)])
    cfg={'niveis_preco_relativos':[0.9,1,1.1],'margem_minima_percentual':0.1,'orcamento_promocional':100.}
    return df,cfg

def test_bf_ga():
    df,cfg=fixture();bf=brute_force(df,cfg);ga=genetic_algorithm(df,cfg,123,40,35)
    assert abs(ga['caixa']-bf['caixa'])<1e-6

def test_greedy_respeita_orcamento():
    df,cfg=fixture();result=greedy(df,cfg,[1,1,1]);assert result['gasto_incentivos']<=cfg['orcamento_promocional']

def test_dp_estoque():
    caminho,estoques,valor,estados=otimizar_produto(10,np.array([2.,4.]),np.array([8.,12.]),np.array([10.,12.]),10.,t=4)
    assert len(caminho)==4 and all(s>=0 for s in estoques)

def test_mc_reprodutivel():
    df=pd.DataFrame({'sku':['a'],'preco_atual':[100.]})
    cfg={'numero_semanas':12,'variabilidade':{'sigma_demanda':0.1,'sigma_preco_concorrente':0.1,'sigma_custo_logistico':0.1}}
    a=cenarios(df,cfg,12,42);b=cenarios(df,cfg,12,42)
    assert all(np.array_equal(x,y) for x,y in zip(a,b))
